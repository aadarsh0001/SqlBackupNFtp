using SqlBackupManager.Core;

namespace SqlBackupManager.Worker;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly BackupJobScheduler _scheduler;
    private FileSystemWatcher? _watcher;
    private readonly string _jobsFile = SharedPaths.GetJobsFilePath();
    private DateTime _lastChange = DateTime.MinValue;

    public Worker(ILogger<Worker> logger, BackupJobScheduler scheduler)
    {
        _logger = logger;
        _scheduler = scheduler;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Worker starting at: {time}", DateTimeOffset.Now);
        await _scheduler.SyncScheduledJobsAsync();
        SetupWatcher();
        while (!stoppingToken.IsCancellationRequested)
        {
            await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
        }
    }

    private void SetupWatcher()
    {
        try
        {
            var dir = Path.GetDirectoryName(_jobsFile)!;
            Directory.CreateDirectory(dir);
            _watcher = new FileSystemWatcher(dir, Path.GetFileName(_jobsFile))
            {
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName
            };
            _watcher.Changed += async (_, __) => await OnJobsFileChanged();
            _watcher.Created += async (_, __) => await OnJobsFileChanged();
            _watcher.Renamed += async (_, __) => await OnJobsFileChanged();
            _watcher.EnableRaisingEvents = true;
            _logger.LogInformation("File watcher initialized for {File}", _jobsFile);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to setup FileSystemWatcher");
        }
    }

    private async Task OnJobsFileChanged()
    {
        var now = DateTime.UtcNow;
        if (now - _lastChange < TimeSpan.FromSeconds(1)) return;
        _lastChange = now;
        try
        {
            _logger.LogInformation("Jobs file change detected. Resyncing schedules...");
            await _scheduler.SyncScheduledJobsAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error syncing after file change");
        }
    }
}
