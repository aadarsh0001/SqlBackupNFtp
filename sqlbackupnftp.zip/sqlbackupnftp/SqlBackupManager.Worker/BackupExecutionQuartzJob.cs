using Quartz;
using SqlBackupManager.Core;

namespace SqlBackupManager.Worker;

public class BackupExecutionQuartzJob : IJob
{
    private readonly IBackupJobStore _store;
    private readonly IBackupExecutionService _exec;
    private readonly ILogger<BackupExecutionQuartzJob> _logger;

    public BackupExecutionQuartzJob(IBackupJobStore store, IBackupExecutionService exec, ILogger<BackupExecutionQuartzJob> logger)
    {
        _store = store;
        _exec = exec;
        _logger = logger;
    }

    public async Task Execute(IJobExecutionContext context)
    {
        if (!Guid.TryParse(context.MergedJobDataMap.GetString("jobId"), out var jobId))
        {
            _logger.LogWarning("JobId missing in job data map");
            return;
        }
        var job = await _store.GetAsync(jobId);
        if (job == null)
        {
            _logger.LogWarning("Job definition {JobId} not found", jobId);
            return;
        }
        if (!job.Enabled)
        {
            _logger.LogInformation("Job {JobName} disabled, skipping", job.JobName);
            return;
        }
        try
        {
            var path = await _exec.ExecuteBackupAsync(job, context.CancellationToken);
            _logger.LogInformation("Backup job {JobName} completed. File: {Path}", job.JobName, path);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing backup job {JobName}", job.JobName);
        }
    }
}
