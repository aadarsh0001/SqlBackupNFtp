using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using SqlBackupManager.Core;
using SqlBackupManager.Worker;
using Quartz;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options => options.ServiceName = "SqlBackupManager");

builder.Services.AddLogging(l =>
{
    l.AddConsole();
    l.AddProvider(new FileLoggerProvider(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SqlBackupManager", "logs", "worker.log")));
});

builder.Services.AddSingleton<IBackupJobStore>(_ => new FileBackupJobStore(SharedPaths.GetJobsFilePath()));
builder.Services.AddSingleton<ISqlMetadataService, SqlMetadataService>();
builder.Services.AddSingleton<IBackupExecutionService, BackupExecutionService>();

builder.Services.AddQuartz();
builder.Services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);

builder.Services.AddSingleton<BackupJobScheduler>();

builder.Services.AddHostedService<Worker>();

var host = builder.Build();

using (var scope = host.Services.CreateScope())
{
    await scope.ServiceProvider.GetRequiredService<BackupJobScheduler>().SyncScheduledJobsAsync();
}

await host.RunAsync();
