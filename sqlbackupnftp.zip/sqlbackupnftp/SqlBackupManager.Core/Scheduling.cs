using Quartz;
using Quartz.Impl.Matchers;
using Microsoft.Extensions.Logging;

namespace SqlBackupManager.Core;

public class BackupJobScheduler
{
    private readonly ISchedulerFactory _schedulerFactory;
    private readonly IBackupJobStore _store;
    private readonly IBackupExecutionService _exec;
    private readonly ILogger<BackupJobScheduler> _logger;

    public BackupJobScheduler(ISchedulerFactory schedulerFactory, IBackupJobStore store, IBackupExecutionService exec, ILogger<BackupJobScheduler> logger)
    {
        _schedulerFactory = schedulerFactory;
        _store = store;
        _exec = exec;
        _logger = logger;
    }

    public async Task SyncScheduledJobsAsync()
    {
        var scheduler = await _schedulerFactory.GetScheduler();
        var existing = await scheduler.GetJobKeys(GroupMatcher<JobKey>.AnyGroup());
        foreach (var key in existing)
        {
            await scheduler.DeleteJob(key);
        }
        var jobs = await _store.GetAllAsync();
        foreach (var job in jobs.Where(j => j.Enabled))
        {
            await ScheduleJobAsync(job);
        }
        _logger.LogInformation("[Scheduler] Scheduled {Count} enabled jobs", jobs.Count(j => j.Enabled));
    }

    public async Task ScheduleJobAsync(BackupJobDefinition job)
    {
        if (!Directory.Exists(job.BackupDirectory))
        {
            try { Directory.CreateDirectory(job.BackupDirectory); } catch { /* ignore */ }
        }
        var scheduler = await _schedulerFactory.GetScheduler();
        var jobDetail = JobBuilder.Create<BackupExecutionQuartzJob>()
            .WithIdentity(job.Id.ToString(), "backup")
            .UsingJobData("jobId", job.Id.ToString())
            .Build();
        ITrigger trigger;
        if (job.FrequencyType == BackupFrequencyType.Cron && !string.IsNullOrWhiteSpace(job.CronExpression))
        {
            trigger = TriggerBuilder.Create().WithIdentity($"trigger-{job.Id}", "backup").WithCronSchedule(job.CronExpression).StartNow().Build();
        }
        else
        {
            var interval = job.Interval <= 0 ? 60 : job.Interval;
            var ts = job.FrequencyType switch
            {
                BackupFrequencyType.Seconds => TimeSpan.FromSeconds(interval),
                BackupFrequencyType.Minutes => TimeSpan.FromMinutes(interval),
                BackupFrequencyType.Hours => TimeSpan.FromHours(interval),
                BackupFrequencyType.Daily => TimeSpan.FromDays(interval),
                BackupFrequencyType.Weekly => TimeSpan.FromDays(7 * interval),
                _ => TimeSpan.FromMinutes(interval)
            };
            trigger = TriggerBuilder.Create().WithIdentity($"trigger-{job.Id}", "backup").StartNow().WithSimpleSchedule(x => x.WithInterval(ts).RepeatForever()).Build();
        }
        await scheduler.ScheduleJob(jobDetail, trigger);
        _logger.LogInformation("[Scheduler] Job {Name} scheduled every {Interval} {Freq}", job.JobName, job.Interval, job.FrequencyType);
    }
}

public class BackupExecutionQuartzJob : IJob
{
    private readonly IBackupJobStore _store;
    private readonly IBackupExecutionService _exec;
    private readonly ILogger<BackupExecutionQuartzJob> _logger;

    public BackupExecutionQuartzJob(IBackupJobStore store, IBackupExecutionService exec, ILogger<BackupExecutionQuartzJob> logger)
    {
        _store = store;
        _exec = exec;
        _logger = logger;
    }

    public async Task Execute(IJobExecutionContext context)
    {
        if (!Guid.TryParse(context.MergedJobDataMap.GetString("jobId"), out var jobId))
        {
            _logger.LogWarning("[Scheduler] jobId missing");
            return;
        }
        var job = await _store.GetAsync(jobId);
        if (job == null || !job.Enabled)
        {
            _logger.LogWarning("[Scheduler] Job {JobId} missing or disabled", jobId);
            return;
        }
        job.LastRunUtc = DateTime.UtcNow;
        try
        {
            var path = await _exec.ExecuteBackupAsync(job, context.CancellationToken);
            job.LastSuccessUtc = DateTime.UtcNow;
            job.LastResultPath = path;
            job.LastError = null;
            _logger.LogInformation("[Scheduler] Backup completed: {JobName} -> {Path}", job.JobName, path);
        }
        catch (Exception ex)
        {
            job.LastError = ex.Message;
            _logger.LogError(ex, "[Scheduler] Backup failed for {JobName}", job.JobName);
        }
        finally
        {
            await _store.AddOrUpdateAsync(job);
        }
    }
}
