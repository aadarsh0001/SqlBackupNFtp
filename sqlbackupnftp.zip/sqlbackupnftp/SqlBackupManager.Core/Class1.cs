﻿namespace SqlBackupManager.Core;

public static class SharedPaths
{
    public static string GetJobsFilePath()
    {
        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SqlBackupManager");
        Directory.CreateDirectory(root);
        return Path.Combine(root, "jobs.json");
    }
}

public enum AuthenticationType
{
    Windows,
    SqlServer
}

public class SqlConnectionInfo
{
    public string ServerName { get; set; } = string.Empty;
    public AuthenticationType AuthenticationType { get; set; }
    public string? UserName { get; set; }
    public string? Password { get; set; }
}

public class DatabaseInfo
{
    public string Name { get; set; } = string.Empty;
}

public enum BackupFrequencyType
{
    Seconds,
    Minutes,
    Hours,
    Daily,
    Weekly,
    Cron
}

public class BackupJobDefinition
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string JobName { get; set; } = string.Empty;
    public SqlConnectionInfo Connection { get; set; } = new();
    public string DatabaseName { get; set; } = string.Empty;
    public string BackupDirectory { get; set; } = string.Empty;
    public BackupFrequencyType FrequencyType { get; set; }
    public int Interval { get; set; } // number of seconds/minutes/hours depending on FrequencyType
    public string? CronExpression { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public bool Enabled { get; set; } = true;
    // Tracking
    public DateTime? LastRunUtc { get; set; }
    public DateTime? LastSuccessUtc { get; set; }
    public string? LastResultPath { get; set; }
    public string? LastError { get; set; }
}

public interface ISqlMetadataService
{
    Task<IReadOnlyList<DatabaseInfo>> GetDatabasesAsync(SqlConnectionInfo info, CancellationToken ct = default);
}

public interface IBackupExecutionService
{
    Task<string> ExecuteBackupAsync(BackupJobDefinition job, CancellationToken ct = default);
}

public interface IBackupJobStore
{
    Task<IReadOnlyList<BackupJobDefinition>> GetAllAsync();
    Task<BackupJobDefinition?> GetAsync(Guid id);
    Task AddOrUpdateAsync(BackupJobDefinition job);
    Task DeleteAsync(Guid id);
}

// Simple file-based store (JSON) skeleton
public class FileBackupJobStore : IBackupJobStore
{
    private readonly string _filePath;
    private readonly SemaphoreSlim _lock = new(1,1);

    public FileBackupJobStore(string filePath)
    {
        _filePath = filePath;
    }

    private async Task<List<BackupJobDefinition>> LoadAsync()
    {
        if (!File.Exists(_filePath)) return new List<BackupJobDefinition>();
        await using var stream = File.OpenRead(_filePath);
        return await System.Text.Json.JsonSerializer.DeserializeAsync<List<BackupJobDefinition>>(stream) ?? new();
    }

    private async Task SaveAsync(List<BackupJobDefinition> jobs)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);
        await using var stream = File.Create(_filePath);
        await System.Text.Json.JsonSerializer.SerializeAsync(stream, jobs, new System.Text.Json.JsonSerializerOptions{WriteIndented=true});
    }

    public async Task<IReadOnlyList<BackupJobDefinition>> GetAllAsync()
    {
        await _lock.WaitAsync();
        try { return await LoadAsync(); }
        finally { _lock.Release(); }
    }

    public async Task<BackupJobDefinition?> GetAsync(Guid id)
    {
        await _lock.WaitAsync();
        try { return (await LoadAsync()).FirstOrDefault(j => j.Id == id); }
        finally { _lock.Release(); }
    }

    public async Task AddOrUpdateAsync(BackupJobDefinition job)
    {
        await _lock.WaitAsync();
        try {
            var list = await LoadAsync();
            var existing = list.FindIndex(j => j.Id == job.Id);
            if (existing >= 0) list[existing] = job; else list.Add(job);
            await SaveAsync(list);
        }
        finally { _lock.Release(); }
    }

    public async Task DeleteAsync(Guid id)
    {
        await _lock.WaitAsync();
        try {
            var list = await LoadAsync();
            list.RemoveAll(j => j.Id == id);
            await SaveAsync(list);
        }
        finally { _lock.Release(); }
    }
}

public class SqlMetadataService : ISqlMetadataService
{
    public async Task<IReadOnlyList<DatabaseInfo>> GetDatabasesAsync(SqlConnectionInfo info, CancellationToken ct = default)
    {
        var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
        {
            DataSource = info.ServerName,
            IntegratedSecurity = info.AuthenticationType == AuthenticationType.Windows,
            TrustServerCertificate = true,
            Encrypt = false
        };
        if (info.AuthenticationType == AuthenticationType.SqlServer)
        {
            builder.UserID = info.UserName;
            builder.Password = info.Password;
        }
        using var conn = new Microsoft.Data.SqlClient.SqlConnection(builder.ConnectionString);
        await conn.OpenAsync(ct);
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT name FROM sys.databases WHERE database_id > 4 ORDER BY name";
        var list = new List<DatabaseInfo>();
        using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            list.Add(new DatabaseInfo { Name = reader.GetString(0) });
        }
        return list;
    }
}

public class BackupExecutionService : IBackupExecutionService
{
    public async Task<string> ExecuteBackupAsync(BackupJobDefinition job, CancellationToken ct = default)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
        var fileName = $"{job.DatabaseName}_{timestamp}.bak";
        Directory.CreateDirectory(job.BackupDirectory);
        var fullPath = Path.Combine(job.BackupDirectory, fileName);
        var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
        {
            DataSource = job.Connection.ServerName,
            IntegratedSecurity = job.Connection.AuthenticationType == AuthenticationType.Windows,
            InitialCatalog = job.DatabaseName,
            TrustServerCertificate = true,
            Encrypt = false
        };
        if (job.Connection.AuthenticationType == AuthenticationType.SqlServer)
        {
            builder.UserID = job.Connection.UserName;
            builder.Password = job.Connection.Password;
        }
        var sql = $"BACKUP DATABASE [{job.DatabaseName}] TO DISK = @path WITH INIT";
        await using var conn = new Microsoft.Data.SqlClient.SqlConnection(builder.ConnectionString);
        await conn.OpenAsync(ct);
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.Parameters.Add(new Microsoft.Data.SqlClient.SqlParameter("@path", fullPath));
        await cmd.ExecuteNonQueryAsync(ct);
        return fullPath;
    }
}
