﻿using System;
using System.IO;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using SqlBackupManager.Core;
using System.Threading.Tasks;
using System.Windows.Controls; // for ComboBoxItem
using Microsoft.Data.SqlClient; // for executing backup directly
using System.ServiceProcess;
using System.Diagnostics;
using Quartz; // added
using Quartz.Impl; // added
using Quartz.Impl.Matchers; // added
using System.Linq; // added
using System.Security.Principal; // for admin check

namespace SqlBackupManager.UI;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window, INotifyPropertyChanged
{
    private string _serverName = @"(localdb)\MSSQLLocalDB";
    private string _userName = string.Empty;
    private string _password = string.Empty;
    private string _backupDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
    private string _interval = "5";
    private string _jobName = string.Empty;
    private object? _selectedAuthType;
    private object? _selectedFrequency;
    private BackupJobDefinition? _selectedJob;
    private string _serviceStatus = "Unknown";
    private const string ServiceNameConst = "SqlBackupManager";
    private const string DeployedWorkerRoot = "%PROGRAMDATA%/SqlBackupManager/Worker";

    private static bool _workerBuildInProgress;
    private IScheduler? _embeddedScheduler;
    private bool _embeddedActive;

    public ObservableCollection<DatabaseInfo> Databases { get; } = new();
    public DatabaseInfo? SelectedDatabase { get; set; }
    public ObservableCollection<BackupJobDefinition> Jobs { get; } = new();

    private readonly ISqlMetadataService _metadataService;
    private readonly IBackupJobStore _store;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        _metadataService = new SqlMetadataService();
        var jobsPath = SharedPaths.GetJobsFilePath();
        _store = new FileBackupJobStore(jobsPath);
        _selectedAuthType = "Windows";
        _selectedFrequency = "Minutes";
        Loaded += async (_, _) => { await RefreshJobsAsync(); RefreshServiceStatus(); };
    }

    public string ServerName { get => _serverName; set { _serverName = value; OnPropertyChanged(); } }
    public string UserName { get => _userName; set { _userName = value; OnPropertyChanged(); } }
    public string BackupDirectory { get => _backupDirectory; set { _backupDirectory = value; OnPropertyChanged(); } }
    public string Interval { get => _interval; set { _interval = value; OnPropertyChanged(); } }
    public string JobName { get => _jobName; set { _jobName = value; OnPropertyChanged(); } }
    public object? SelectedAuthType { get => _selectedAuthType; set { _selectedAuthType = value; OnPropertyChanged(); } }
    public object? SelectedFrequency { get => _selectedFrequency; set { _selectedFrequency = value; OnPropertyChanged(); } }
    public BackupJobDefinition? SelectedJob { get => _selectedJob; set { _selectedJob = value; OnPropertyChanged(); } }
    public string ServiceStatus { get => _serviceStatus; set { _serviceStatus = value; OnPropertyChanged(); } }

    private string? GetSelectedFrequencyText()
    {
        return SelectedFrequency switch
        {
            ComboBoxItem cbi => cbi.Content?.ToString(),
            _ => SelectedFrequency?.ToString()
        };
    }

    private AuthenticationType GetAuthType() => SelectedAuthType?.ToString() == "SqlServer" ? AuthenticationType.SqlServer : AuthenticationType.Windows;
    private BackupFrequencyType GetFrequencyType() => GetSelectedFrequencyText() switch
    {
        "Seconds" => BackupFrequencyType.Seconds,
        "Minutes" => BackupFrequencyType.Minutes,
        "Hours" => BackupFrequencyType.Hours,
        "Daily" => BackupFrequencyType.Daily,
        "Weekly" => BackupFrequencyType.Weekly,
        _ => BackupFrequencyType.Minutes
    };

    private async void Connect_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Databases.Clear();
            var info = new SqlConnectionInfo
            {
                ServerName = ServerName,
                AuthenticationType = GetAuthType(),
                UserName = UserName,
                Password = _password
            };
            var dbs = await _metadataService.GetDatabasesAsync(info);
            foreach (var db in dbs) Databases.Add(db);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Connection Error");
        }
    }

    private async Task EnsureEmbeddedSchedulerAsync()
    {
        if (_embeddedScheduler != null) return;
        var factory = new StdSchedulerFactory();
        _embeddedScheduler = await factory.GetScheduler();
        await _embeddedScheduler.Start();
    }

    private async Task EmbeddedRescheduleAsync()
    {
        if (ServiceStatus != "NotInstalled" && ServiceStatus != "Stopped") return; // service running, no need embed
        await EnsureEmbeddedSchedulerAsync();
        _embeddedActive = true;
        var sched = _embeddedScheduler!;
        // clear existing
        var jobKeys = await sched.GetJobKeys(GroupMatcher<JobKey>.AnyGroup());
        foreach (var k in jobKeys) await sched.DeleteJob(k);
        foreach (var job in Jobs.Where(j => j.Enabled))
        {
            var jobDetail = JobBuilder.Create<InlineBackupJob>()
                .WithIdentity(job.Id.ToString(), "ui")
                .UsingJobData("jobId", job.Id.ToString())
                .Build();
            var interval = job.Interval <= 0 ? 60 : job.Interval;
            TimeSpan ts = job.FrequencyType switch
            {
                BackupFrequencyType.Seconds => TimeSpan.FromSeconds(interval),
                BackupFrequencyType.Minutes => TimeSpan.FromMinutes(interval),
                BackupFrequencyType.Hours => TimeSpan.FromHours(interval),
                BackupFrequencyType.Daily => TimeSpan.FromDays(interval),
                BackupFrequencyType.Weekly => TimeSpan.FromDays(7 * interval),
                _ => TimeSpan.FromMinutes(interval)
            };
            ITrigger trigger = TriggerBuilder.Create()
                .WithIdentity($"trigger-{job.Id}", "ui")
                .StartNow()
                .WithSimpleSchedule(x => x.WithInterval(ts).RepeatForever())
                .Build();
            await sched.ScheduleJob(jobDetail, trigger);
        }
    }

    private async Task PersistAndMaybeRescheduleAsync()
    {
        await _store.AddOrUpdateAsync(SelectedJob!);
        await RefreshJobsAsync();
        await EmbeddedRescheduleAsync();
    }

    private async void EnableJob_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedJob == null) return;
        SelectedJob.Enabled = true;
        await PersistAndMaybeRescheduleAsync();
    }

    private async void DisableJob_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedJob == null) return;
        SelectedJob.Enabled = false;
        await PersistAndMaybeRescheduleAsync();
    }

    private async void DeleteJob_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedJob == null) return;
        await _store.DeleteAsync(SelectedJob.Id);
        await RefreshJobsAsync();
        await EmbeddedRescheduleAsync();
    }

    private async void SaveJob_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedJob == null) return;
        await PersistAndMaybeRescheduleAsync();
    }

    private async void AddJob_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedDatabase == null)
        {
            MessageBox.Show("Select a database first");
            return;
        }
        if (!int.TryParse(Interval, out var interval)) interval = 5;
        var job = new BackupJobDefinition
        {
            JobName = string.IsNullOrWhiteSpace(JobName) ? $"Backup_{SelectedDatabase.Name}" : JobName,
            Connection = new SqlConnectionInfo
            {
                ServerName = ServerName,
                AuthenticationType = GetAuthType(),
                UserName = UserName,
                Password = _password
            },
            DatabaseName = SelectedDatabase.Name,
            BackupDirectory = BackupDirectory,
            FrequencyType = GetFrequencyType(),
            Interval = interval,
            Enabled = true
        };
        await _store.AddOrUpdateAsync(job);
        await RefreshJobsAsync();
        await EmbeddedRescheduleAsync();
        _ = AutoEnsureServiceForSchedulingAsync(); // fire & forget
        MessageBox.Show($"Job added with frequency {job.FrequencyType}. Service setup will continue in background if needed.");
    }

    private async Task RefreshJobsAsync()
    {
        Jobs.Clear();
        var list = await _store.GetAllAsync();
        foreach (var j in list) Jobs.Add(j);
        if (_embeddedActive) await EmbeddedRescheduleAsync();
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new System.Windows.Forms.FolderBrowserDialog();
        if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            BackupDirectory = dlg.SelectedPath;
        }
    }

    private void PasswordBox_OnPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (sender is System.Windows.Controls.PasswordBox pb)
        {
            _password = pb.Password;
        }
    }

    private async void RunNow_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedJob == null)
        {
            MessageBox.Show("Select a job first.");
            return;
        }
        try
        {
            // Execute immediate backup inline (duplicate logic; for production better to reuse service abstraction)
            var job = SelectedJob;
            var builder = new SqlConnectionStringBuilder
            {
                DataSource = job.Connection.ServerName,
                IntegratedSecurity = job.Connection.AuthenticationType == AuthenticationType.Windows,
                InitialCatalog = job.DatabaseName,
                TrustServerCertificate = true,
                Encrypt = false
            };
            if (job.Connection.AuthenticationType == AuthenticationType.SqlServer)
            {
                builder.UserID = job.Connection.UserName;
                builder.Password = job.Connection.Password;
            }
            Directory.CreateDirectory(job.BackupDirectory);
            var timestamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var fileName = $"{job.DatabaseName}_{timestamp}_manual.bak";
            var fullPath = Path.Combine(job.BackupDirectory, fileName);
            await using var conn = new SqlConnection(builder.ConnectionString);
            await conn.OpenAsync();
            var sql = $"BACKUP DATABASE [{job.DatabaseName}] TO DISK=@p WITH INIT";
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.Parameters.Add(new SqlParameter("@p", fullPath));
            await cmd.ExecuteNonQueryAsync();
            job.LastRunUtc = DateTime.UtcNow;
            job.LastSuccessUtc = DateTime.UtcNow;
            job.LastResultPath = fullPath;
            job.LastError = null;
            await _store.AddOrUpdateAsync(job);
            await RefreshJobsAsync();
            MessageBox.Show($"Manual backup created: {fullPath}");
        }
        catch (Exception ex)
        {
            if (SelectedJob != null)
            {
                SelectedJob.LastRunUtc = DateTime.UtcNow;
                SelectedJob.LastError = ex.Message;
                await _store.AddOrUpdateAsync(SelectedJob);
            }
            MessageBox.Show("Manual backup failed: " + ex.Message);
        }
    }

    private void RefreshServiceStatus()
    {
        try
        {
            using var sc = new ServiceController(ServiceNameConst);
            ServiceStatus = sc.Status.ToString();
        }
        catch
        {
            ServiceStatus = "NotInstalled";
        }
    }

    private string GetWorkerExePath()
    {
        // Search upward for solution root containing SqlBackupManager.Worker folder
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (int i = 0; i < 8 && dir != null; i++)
        {
            var workerDir = Path.Combine(dir.FullName, "SqlBackupManager.Worker");
            if (Directory.Exists(workerDir))
            {
                // preferred published path
                var publishExe = Path.Combine(workerDir, "bin", "Release", "net8.0", "publish", "SqlBackupManager.Worker.exe");
                if (File.Exists(publishExe)) return publishExe;
                var debugExe = Path.Combine(workerDir, "bin", "Debug", "net8.0", "SqlBackupManager.Worker.exe");
                if (File.Exists(debugExe)) return debugExe;
            }
            dir = dir.Parent;
        }
        return string.Empty;
    }

    private async Task<string> EnsureWorkerExeAsync()
    {
        var exe = GetWorkerExePath();
        if (!string.IsNullOrEmpty(exe) && File.Exists(exe)) return exe;
        if (_workerBuildInProgress) return string.Empty; // avoid re-entry
        _workerBuildInProgress = true;
        try
        {
            // Try to build then publish Worker automatically
            var solutionDir = FindSolutionRoot();
            if (solutionDir == null)
            {
                MessageBox.Show("Cannot locate solution root to build Worker.");
                return string.Empty;
            }
            var workerProj = Path.Combine(solutionDir.FullName, "SqlBackupManager.Worker", "SqlBackupManager.Worker.csproj");
            if (!File.Exists(workerProj))
            {
                MessageBox.Show("Worker project file not found.");
                return string.Empty;
            }
            await RunDotNetAsync($"build \"{workerProj}\" -c Release");
            await RunDotNetAsync($"publish \"{workerProj}\" -c Release -o \"{Path.Combine(solutionDir.FullName, "SqlBackupManager.Worker", "bin", "Release", "net8.0", "publish")}\"");
            exe = GetWorkerExePath();
            return exe;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Auto build/publish of Worker failed: " + ex.Message);
            return string.Empty;
        }
        finally { _workerBuildInProgress = false; }
    }

    private DirectoryInfo? FindSolutionRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        for (int i = 0; i < 8 && dir != null; i++)
        {
            if (File.Exists(Path.Combine(dir.FullName, "SqlBackupManager.sln"))) return dir;
            dir = dir.Parent;
        }
        return null;
    }

    private async Task RunDotNetAsync(string arguments)
    {
        var psi = new ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = arguments,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        using var p = Process.Start(psi)!;
        var stdout = await p.StandardOutput.ReadToEndAsync();
        var stderr = await p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync();
        if (p.ExitCode != 0)
        {
            throw new InvalidOperationException($"dotnet {arguments} failed:\n{stderr}\n{stdout}");
        }
    }

    private async Task<bool> EnsureServiceInstalledAsync()
    {
        RefreshServiceStatus();
        if (ServiceStatus != "NotInstalled") return true;
        var exePath = await EnsureWorkerExeAsync();
        if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
        {
            MessageBox.Show("Worker executable could not be built automatically.");
            return false;
        }
        try
        {
            // Use sc.exe to create service
            var psi = new ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = $"create {ServiceNameConst} binPath= \"{exePath}\" start= auto",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi)!;
            await p.WaitForExitAsync();
            RefreshServiceStatus();
            return ServiceStatus != "NotInstalled";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Failed to install service: " + ex.Message);
            return false;
        }
    }

    private async void StartService_Click(object sender, RoutedEventArgs e)
    {
        await AutoEnsureServiceForSchedulingAsync();
    }

    private void StopService_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var sc = new ServiceController(ServiceNameConst);
            if (sc.Status == ServiceControllerStatus.Stopped) { RefreshServiceStatus(); return; }
            sc.Stop();
            sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15));
        }
        catch (Exception ex)
        {
            MessageBox.Show("Failed to stop service: " + ex.Message);
        }
        RefreshServiceStatus();
    }

    private async void UninstallService_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var sc = new ServiceController(ServiceNameConst);
            if (sc.Status != ServiceControllerStatus.Stopped)
            {
                sc.Stop();
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(10));
            }
        }
        catch { }
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = $"delete {ServiceNameConst}",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi)!;
            await p.WaitForExitAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Failed to uninstall service: " + ex.Message);
        }
        RefreshServiceStatus();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    void OnPropertyChanged([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    // Inline backup job for embedded scheduler
    public class InlineBackupJob : IJob
    {
        public async Task Execute(IJobExecutionContext context)
        {
            try
            {
                if (!Guid.TryParse(context.MergedJobDataMap.GetString("jobId"), out var id)) return;
                var store = new FileBackupJobStore(SharedPaths.GetJobsFilePath());
                var job = await store.GetAsync(id);
                if (job == null || !job.Enabled) return;
                var exec = new BackupExecutionService();
                job.LastRunUtc = DateTime.UtcNow;
                try
                {
                    var path = await exec.ExecuteBackupAsync(job, context.CancellationToken);
                    job.LastSuccessUtc = DateTime.UtcNow;
                    job.LastResultPath = path;
                    job.LastError = null;
                }
                catch (Exception ex)
                {
                    job.LastError = ex.Message;
                }
                await store.AddOrUpdateAsync(job);
            }
            catch { }
        }
    }

    private async void RefreshJobs_Click(object? sender, RoutedEventArgs e)
    {
        await RefreshJobsAsync();
    }

    // Helper to check admin rights
    private static bool IsAdministrator()
    {
        try
        {
            using var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
        catch { return false; }
    }

    // Deploy worker to ProgramData so service path is stable (independent from solution folder)
    private async Task<string> DeployWorkerAsync()
    {
        var expanded = Environment.ExpandEnvironmentVariables(DeployedWorkerRoot);
        Directory.CreateDirectory(expanded);
        var exePath = await EnsureWorkerExeAsync();
        if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath)) return string.Empty;
        var targetExe = Path.Combine(expanded, "SqlBackupManager.Worker.exe");
        try
        {
            foreach (var file in Directory.EnumerateFiles(Path.GetDirectoryName(exePath)!, "*", SearchOption.TopDirectoryOnly))
            {
                var dest = Path.Combine(expanded, Path.GetFileName(file));
                File.Copy(file, dest, true);
            }
            return targetExe;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Deploy worker failed: " + ex.Message);
            return string.Empty;
        }
    }

    private async Task<bool> AutoEnsureServiceForSchedulingAsync()
    {
        // Called after adding first enabled job
        RefreshServiceStatus();
        if (ServiceStatus == "Running" || Jobs.All(j => !j.Enabled)) return true;
        // Try to install/start service silently
        if (ServiceStatus == "NotInstalled")
        {
            if (!IsAdministrator())
            {
                // Attempt elevation
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = Environment.ProcessPath!,
                        Arguments = "--elevated-install",
                        UseShellExecute = true,
                        Verb = "runas"
                    };
                    Process.Start(psi);
                    MessageBox.Show("Elevating to install service. After installation the service will run backups without the UI.");
                    return false; // current instance will not install
                }
                catch
                {
                    // fallback to embedded scheduler only
                    await EmbeddedRescheduleAsync();
                    return false;
                }
            }
            // Admin: deploy and install
            var deployedExe = await DeployWorkerAsync();
            if (string.IsNullOrEmpty(deployedExe)) return false;
            await InstallServiceAtPathAsync(deployedExe);
        }
        if (ServiceStatus == "Stopped") StartServiceInternal();
        return ServiceStatus == "Running";
    }

    private async Task InstallServiceAtPathAsync(string exePath)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "sc.exe",
                Arguments = $"create {ServiceNameConst} binPath= \"{exePath}\" start= auto",
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi)!; await p.WaitForExitAsync();
            RefreshServiceStatus();
            if (ServiceStatus != "Running") StartServiceInternal();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Service install failed: " + ex.Message);
        }
    }

    // Refactor service start internal to reuse
    private void StartServiceInternal()
    {
        try
        {
            using var sc = new ServiceController(ServiceNameConst);
            if (sc.Status != ServiceControllerStatus.Running)
            {
                sc.Start();
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(20));
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Failed to start service: " + ex.Message);
        }
        RefreshServiceStatus();
    }

    // Handle elevated install command-line arg
    protected override async void OnContentRendered(EventArgs e)
    {
        base.OnContentRendered(e);
        var args = Environment.GetCommandLineArgs();
        if (args.Contains("--elevated-install") && IsAdministrator())
        {
            // Attempt install then exit (UI can be reopened normally)
            var exe = await DeployWorkerAsync();
            if (!string.IsNullOrEmpty(exe)) await InstallServiceAtPathAsync(exe);
            Close();
        }
    }
}